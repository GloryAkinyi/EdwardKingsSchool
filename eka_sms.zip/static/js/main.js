// Edward Kings Academy SMS - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
  // Sidebar toggle
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const mainWrapper = document.getElementById('mainWrapper');

  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', function() {
      sidebar.classList.toggle('open');
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
      if (window.innerWidth <= 991 &&
          sidebar.classList.contains('open') &&
          !sidebar.contains(e.target) &&
          !sidebarToggle.contains(e.target)) {
        sidebar.classList.remove('open');
      }
    });
  }

  // Auto-dismiss alerts
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      const bsAlert = new bootstrap.Alert(alert);
      if (bsAlert) bsAlert.close();
    }, 5000);
  });

  // Initialize DataTables
  document.querySelectorAll('.data-table').forEach(table => {
    if ($.fn.DataTable) {
      $(table).DataTable({
        responsive: true,
        pageLength: 25,
        dom: '<"d-flex justify-content-between align-items-center mb-3"lf>rt<"d-flex justify-content-between"ip>',
        language: {
          search: '',
          searchPlaceholder: 'Search...',
          lengthMenu: 'Show _MENU_ entries',
        }
      });
    }
  });

  // Animate numbers on dashboard
  document.querySelectorAll('.stat-value[data-count]').forEach(el => {
    const target = parseInt(el.getAttribute('data-count'));
    const duration = 1200;
    const step = target / (duration / 16);
    let current = 0;
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = Math.round(current).toLocaleString();
      if (current >= target) clearInterval(timer);
    }, 16);
  });

  // Stream filter for student list
  const gradeFilter = document.getElementById('gradeFilter');
  const streamFilter = document.getElementById('streamFilter');

  if (gradeFilter && streamFilter) {
    gradeFilter.addEventListener('change', function() {
      const gradeId = this.value;
      // Filter stream options by grade
      Array.from(streamFilter.options).forEach(opt => {
        if (!opt.value || !gradeId) {
          opt.style.display = '';
        } else {
          opt.style.display = opt.dataset.grade === gradeId ? '' : 'none';
        }
      });
      streamFilter.value = '';
    });
  }

  // Dynamic stream load for promotion page
  const fromStreamSelect = document.getElementById('id_from_stream');
  const studentCheckboxes = document.getElementById('student-checkboxes');

  if (fromStreamSelect && studentCheckboxes) {
    fromStreamSelect.addEventListener('change', function() {
      const streamId = this.value;
      if (!streamId) { studentCheckboxes.innerHTML = ''; return; }

      fetch(`/students/api/stream-students/?stream_id=${streamId}`)
        .then(res => res.json())
        .then(data => {
          studentCheckboxes.innerHTML = '';
          if (data.students.length === 0) {
            studentCheckboxes.innerHTML = '<p class="text-muted small">No active students in this stream.</p>';
            return;
          }
          data.students.forEach(s => {
            studentCheckboxes.innerHTML += `
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="student_ids"
                  value="${s.id}" id="stu_${s.id}" checked>
                <label class="form-check-label" for="stu_${s.id}">
                  <span class="fw-semibold">${s.first_name} ${s.last_name}</span>
                  <small class="text-muted ms-2">${s.admission_number}</small>
                </label>
              </div>`;
          });
        })
        .catch(() => {
          studentCheckboxes.innerHTML = '<p class="text-danger small">Error loading students.</p>';
        });
    });
  }

  // Fee payment: show student fee structures
  const paymentStudent = document.getElementById('paymentStudent');
  const paymentStructure = document.getElementById('paymentStructure');

  if (paymentStudent && paymentStructure) {
    paymentStudent.addEventListener('change', function() {
      // Could fetch student's applicable fee structures via AJAX
    });
  }

  // Attendance all-present toggle
  const markAllPresent = document.getElementById('markAllPresent');
  if (markAllPresent) {
    markAllPresent.addEventListener('click', function() {
      document.querySelectorAll('.att-select').forEach(sel => {
        sel.value = 'present';
        sel.closest('tr').classList.remove('table-danger', 'table-warning');
        sel.closest('tr').classList.add('table-success');
      });
    });
  }

  // Attendance row colour coding
  document.querySelectorAll('.att-select').forEach(sel => {
    sel.addEventListener('change', function() {
      const row = this.closest('tr');
      row.classList.remove('table-success', 'table-danger', 'table-warning');
      if (this.value === 'present') row.classList.add('table-success');
      else if (this.value === 'absent') row.classList.add('table-danger');
      else if (this.value === 'late') row.classList.add('table-warning');
    });
  });
});

// Print receipt
function printReceipt() {
  window.print();
}

// Charts helper
function createDoughnutChart(canvasId, labels, data, colors) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: colors,
        borderWidth: 0,
        hoverOffset: 6,
      }]
    },
    options: {
      cutout: '70%',
      plugins: {
        legend: {
          labels: { color: '#8fa399', font: { size: 12 }, padding: 16 }
        }
      },
      responsive: true,
      maintainAspectRatio: false,
    }
  });
}

function createBarChart(canvasId, labels, datasets) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: { labels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: '#8fa399' } }
      },
      scales: {
        x: { ticks: { color: '#8fa399' }, grid: { color: 'rgba(16,42,34,0.5)' } },
        y: { ticks: { color: '#8fa399' }, grid: { color: 'rgba(16,42,34,0.5)' } }
      }
    }
  });
}
