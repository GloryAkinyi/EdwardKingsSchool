import urllib.request
import urllib.parse
import json
import ssl

context = ssl._create_unverified_context()

url = "https://cpanel.edwardkings.sc.ke:2083/login/?login_only=1"
data = urllib.parse.urlencode({
    "user": "edwardk1",
    "pass": "E271;a#HwY4emY"
}).encode('utf-8')

req = urllib.request.Request(url, data=data)
try:
    with urllib.request.urlopen(req, context=context, timeout=10) as response:
        print("Status:", response.status)
        print("Body:", response.read().decode('utf-8'))
except Exception as e:
    print("Error:", e)
