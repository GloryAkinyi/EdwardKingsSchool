from django import forms
from .models import FeeStructure, FeeItem, FeePayment
from academics.models import GradeLevel, Term


class FeeStructureForm(forms.ModelForm):
    class Meta:
        model = FeeStructure
        fields = ['name', 'grade_level', 'term', 'total_amount', 'description']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g. PP1 Term 1 2024 Fees'
            }),
            'grade_level': forms.Select(attrs={'class': 'form-select'}),
            'term': forms.Select(attrs={'class': 'form-select'}),
            'total_amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g. 15000',
                'min': '0',
                'step': '0.01'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Optional notes about this fee structure...'
            }),
        }


class FeeItemForm(forms.ModelForm):
    class Meta:
        model = FeeItem
        fields = ['name', 'amount']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g. Tuition, Activity Fee, Uniform'
            }),
            'amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g. 10000',
                'min': '0',
                'step': '0.01'
            }),
        }
