from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Sum, Count, Q
from .models import FeeStructure, FeePayment, FeeItem
from .forms import FeeStructureForm, FeeItemForm
from students.models import Student
from academics.models import GradeLevel, AcademicYear, Term


@login_required
def fee_dashboard(request):
    # Total collected this year
    total_collected = FeePayment.objects.aggregate(total=Sum('amount_paid'))['total'] or 0

    # By grade level
    grade_stats = []
    for grade in GradeLevel.objects.all():
        students = Student.objects.filter(current_grade=grade, status='active')
        collected = FeePayment.objects.filter(student__in=students).aggregate(
            total=Sum('amount_paid'))['total'] or 0
        grade_stats.append({'grade': grade, 'students': students.count(), 'collected': collected})

    # Recent payments
    recent = FeePayment.objects.select_related('student', 'fee_structure').order_by('-payment_date')[:10]

    # Defaulters (students whose paid amount < required)
    defaulters = []
    current_term = Term.objects.filter(is_current=True).first()
    if current_term:
        structures = FeeStructure.objects.filter(term=current_term)
        for structure in structures:
            students_in_grade = Student.objects.filter(
                current_grade=structure.grade_level, status='active'
            )
            for student in students_in_grade:
                payment = FeePayment.objects.filter(
                    student=student, fee_structure=structure
                ).first()
                paid = payment.amount_paid if payment else 0
                balance = structure.total_amount - paid
                if balance > 0:
                    defaulters.append({
                        'student': student,
                        'structure': structure,
                        'paid': paid,
                        'balance': balance,
                    })

    context = {
        'total_collected': total_collected,
        'grade_stats': grade_stats,
        'recent_payments': recent,
        'defaulters': defaulters[:20],  # Limit for dashboard
        'current_term': current_term,
    }
    return render(request, 'fees/dashboard.html', context)


@login_required
def record_payment(request, student_id=None):
    student = None
    if student_id:
        student = get_object_or_404(Student, pk=student_id)

    fee_structures = FeeStructure.objects.select_related('grade_level', 'term').all()
    students = Student.objects.filter(status='active').select_related('current_grade')

    if request.method == 'POST':
        student_id_post = request.POST.get('student')
        structure_id = request.POST.get('fee_structure')
        amount = request.POST.get('amount_paid')
        method = request.POST.get('payment_method')
        ref = request.POST.get('transaction_reference', '')
        notes = request.POST.get('notes', '')

        try:
            s = Student.objects.get(pk=student_id_post)
            fs = FeeStructure.objects.get(pk=structure_id)
            payment = FeePayment.objects.create(
                student=s,
                fee_structure=fs,
                amount_paid=amount,
                payment_method=method,
                transaction_reference=ref,
                notes=notes,
                received_by=request.user,
            )
            messages.success(request, f'Payment of KES {amount} recorded for {s.full_name}')
            return redirect('fees:payment_receipt', pk=payment.pk)
        except Exception as e:
            messages.error(request, f'Error recording payment: {e}')

    context = {
        'student': student,
        'fee_structures': fee_structures,
        'students': students,
        'payment_methods': FeePayment.PAYMENT_METHOD_CHOICES,
    }
    return render(request, 'fees/record_payment.html', context)


@login_required
def payment_receipt(request, pk):
    payment = get_object_or_404(FeePayment, pk=pk)
    return render(request, 'fees/receipt.html', {'payment': payment})


@login_required
def student_fee_statement(request, student_id):
    student = get_object_or_404(Student, pk=student_id)
    payments = FeePayment.objects.filter(student=student).select_related('fee_structure').order_by('-payment_date')
    total_paid = payments.aggregate(total=Sum('amount_paid'))['total'] or 0
    context = {'student': student, 'payments': payments, 'total_paid': total_paid}
    return render(request, 'fees/statement.html', context)


@login_required
def fee_structures(request):
    structures = FeeStructure.objects.select_related('grade_level', 'term').prefetch_related('items').all()
    return render(request, 'fees/structures.html', {'structures': structures})


@login_required
def add_fee_structure(request):
    if request.method == 'POST':
        form = FeeStructureForm(request.POST)
        if form.is_valid():
            structure = form.save()
            messages.success(request, f'Fee structure "{structure.name}" created successfully.')
            return redirect('fees:structures')
    else:
        form = FeeStructureForm()
    return render(request, 'fees/structure_form.html', {'form': form, 'action': 'Add'})


@login_required
def edit_fee_structure(request, pk):
    structure = get_object_or_404(FeeStructure, pk=pk)
    if request.method == 'POST':
        form = FeeStructureForm(request.POST, instance=structure)
        if form.is_valid():
            form.save()
            messages.success(request, f'Fee structure "{structure.name}" updated.')
            return redirect('fees:structures')
    else:
        form = FeeStructureForm(instance=structure)
    return render(request, 'fees/structure_form.html', {
        'form': form, 'action': 'Edit', 'structure': structure
    })


@login_required
def delete_fee_structure(request, pk):
    structure = get_object_or_404(FeeStructure, pk=pk)
    if request.method == 'POST':
        name = structure.name
        structure.delete()
        messages.success(request, f'Fee structure "{name}" deleted.')
        return redirect('fees:structures')
    return render(request, 'fees/structure_confirm_delete.html', {'structure': structure})


@login_required
def add_fee_item(request, structure_pk):
    structure = get_object_or_404(FeeStructure, pk=structure_pk)
    if request.method == 'POST':
        form = FeeItemForm(request.POST)
        if form.is_valid():
            item = form.save(commit=False)
            item.fee_structure = structure
            item.save()
            messages.success(request, f'Fee item "{item.name}" added.')
            return redirect('fees:edit_structure', pk=structure.pk)
    else:
        form = FeeItemForm()
    return render(request, 'fees/fee_item_form.html', {
        'form': form, 'structure': structure
    })


@login_required
def delete_fee_item(request, pk):
    item = get_object_or_404(FeeItem, pk=pk)
    structure_pk = item.fee_structure.pk
    if request.method == 'POST':
        item.delete()
        messages.success(request, 'Fee item deleted.')
        return redirect('fees:edit_structure', pk=structure_pk)
    return render(request, 'fees/fee_item_confirm_delete.html', {
        'item': item, 'structure': item.fee_structure
    })

