from django.db import models
from students.models import Student
from academics.models import AcademicYear, Term


class FeeStructure(models.Model):
    name = models.CharField(max_length=100)  # e.g. "PP1 Term 1 2024 Fees"
    grade_level = models.ForeignKey('academics.GradeLevel', on_delete=models.CASCADE)
    term = models.ForeignKey(Term, on_delete=models.CASCADE)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True)

    class Meta:
        unique_together = ['grade_level', 'term']

    def __str__(self):
        return f"{self.grade_level} - {self.term} - KES {self.total_amount}"


class FeeItem(models.Model):
    fee_structure = models.ForeignKey(FeeStructure, on_delete=models.CASCADE, related_name='items')
    name = models.CharField(max_length=100)  # e.g. "Tuition", "Activity Fee", "Uniform"
    amount = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.name}: KES {self.amount}"


class FeePayment(models.Model):
    PAYMENT_METHOD_CHOICES = [
        ('mpesa', 'M-Pesa'),
        ('cash', 'Cash'),
        ('bank', 'Bank Transfer'),
        ('cheque', 'Cheque'),
    ]
    STATUS_CHOICES = [
        ('paid', 'Paid'),
        ('partial', 'Partial'),
        ('unpaid', 'Unpaid'),
        ('waived', 'Waived'),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='payments')
    fee_structure = models.ForeignKey(FeeStructure, on_delete=models.CASCADE)
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    payment_method = models.CharField(max_length=10, choices=PAYMENT_METHOD_CHOICES, default='cash')
    transaction_reference = models.CharField(max_length=50, blank=True)
    payment_date = models.DateField(auto_now_add=True)
    received_by = models.ForeignKey(
        'auth.User', on_delete=models.SET_NULL, null=True
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-payment_date']

    def __str__(self):
        return f"{self.student.full_name} - KES {self.amount_paid} - {self.payment_date}"

    @property
    def balance(self):
        return self.fee_structure.total_amount - self.amount_paid

    @property
    def status(self):
        if self.amount_paid >= self.fee_structure.total_amount:
            return 'paid'
        elif self.amount_paid > 0:
            return 'partial'
        return 'unpaid'
