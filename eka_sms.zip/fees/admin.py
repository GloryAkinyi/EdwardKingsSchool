from django.contrib import admin
from .models import FeeStructure, FeeItem, FeePayment


class FeeItemInline(admin.TabularInline):
    model = FeeItem
    extra = 3


@admin.register(FeeStructure)
class FeeStructureAdmin(admin.ModelAdmin):
    list_display = ['name', 'grade_level', 'term', 'total_amount']
    list_filter = ['grade_level', 'term__academic_year']
    inlines = [FeeItemInline]


@admin.register(FeePayment)
class FeePaymentAdmin(admin.ModelAdmin):
    list_display = [
        'student', 'fee_structure', 'amount_paid', 'payment_method',
        'transaction_reference', 'payment_date', 'received_by'
    ]
    list_filter = ['payment_method', 'payment_date', 'fee_structure__term']
    search_fields = [
        'student__first_name', 'student__last_name',
        'student__admission_number', 'transaction_reference'
    ]
    date_hierarchy = 'payment_date'
    readonly_fields = ['payment_date']
