from django.urls import path
from . import views

app_name = 'fees'

urlpatterns = [
    path('', views.fee_dashboard, name='dashboard'),
    path('record/', views.record_payment, name='record_payment'),
    path('record/<int:student_id>/', views.record_payment, name='record_payment_student'),
    path('receipt/<int:pk>/', views.payment_receipt, name='payment_receipt'),
    path('statement/<int:student_id>/', views.student_fee_statement, name='statement'),
    path('structures/', views.fee_structures, name='structures'),
    path('structures/add/', views.add_fee_structure, name='add_structure'),
    path('structures/<int:pk>/edit/', views.edit_fee_structure, name='edit_structure'),
    path('structures/<int:pk>/delete/', views.delete_fee_structure, name='delete_structure'),
    path('structures/<int:structure_pk>/items/add/', views.add_fee_item, name='add_fee_item'),
    path('items/<int:pk>/delete/', views.delete_fee_item, name='delete_fee_item'),
]

