import urllib.request
import urllib.parse
import json
import ssl
import http.cookiejar

class CPanelAPI:
    def __init__(self, username, password, host="cpanel.edwardkings.sc.ke"):
        self.username = username
        self.password = password
        self.host = host
        self.base_url = f"https://{host}:2083"
        self.context = ssl._create_unverified_context()
        self.cj = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cj),
            urllib.request.HTTPSHandler(context=self.context)
        )
        self.token = None

    def login(self):
        url = f"{self.base_url}/login/?login_only=1"
        data = urllib.parse.urlencode({
            "user": self.username,
            "pass": self.password
        }).encode('utf-8')
        
        req = urllib.request.Request(url, data=data)
        with self.opener.open(req, timeout=15) as res:
            body = json.loads(res.read().decode('utf-8'))
            if body.get("status") == 1:
                self.token = body.get("security_token")
                print(f"Logged in successfully. Token: {self.token}")
                return True
            else:
                print(f"Login failed: {body}")
                return False

    def execute(self, module, function, **kwargs):
        if not self.token:
            if not self.login():
                raise Exception("Authentication failed")
        
        url = f"{self.base_url}{self.token}/execute/{module}/{function}"
        data = urllib.parse.urlencode(kwargs).encode('utf-8')
        req = urllib.request.Request(url, data=data)
        with self.opener.open(req, timeout=15) as res:
            return json.loads(res.read().decode('utf-8'))

# Test database listing
if __name__ == "__main__":
    api = CPanelAPI("edwardk1", "E271;a#HwY4emY")
    dbs = api.execute("Mysql", "list_databases")
    print(json.dumps(dbs, indent=2))
