#!/bin/bash
# Edward Kings Academy SMS - Full Run Script

cd "$(dirname "$0")"
source venv/bin/activate

echo "============================================"
echo "  Edward Kings Academy SMS"
echo "  Starting Application..."
echo "============================================"

# Collect static
echo "[1/3] Applying migrations..."
python manage.py migrate --run-syncdb

echo "[2/3] Collecting static files..."
python manage.py collectstatic --noinput 2>/dev/null

echo "[3/3] Seeding initial data..."
python seed_data.py

echo ""
echo "✅ Ready! Starting server..."
echo "   🌐 URL: http://127.0.0.1:8000"
echo "   🔑 Login: admin / EKA@admin2024"
echo "   📚 Admin: http://127.0.0.1:8000/admin/"
echo ""

python manage.py runserver 0.0.0.0:8000
