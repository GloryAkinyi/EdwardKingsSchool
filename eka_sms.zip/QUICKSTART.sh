# Edward Kings Academy SMS - Quick Start Guide
# ==============================================
# Run each of the following commands in your terminal

# STEP 1: Start MySQL (run ONCE)
sudo systemctl start mysql

# STEP 2: Create the database (run ONCE, enter MySQL root password when prompted)
sudo mysql -e "
  CREATE DATABASE IF NOT EXISTS edwardkings_sms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
  CREATE USER IF NOT EXISTS 'edwardkings'@'localhost' IDENTIFIED BY 'EKings2024#';
  GRANT ALL PRIVILEGES ON edwardkings_sms.* TO 'edwardkings'@'localhost';
  FLUSH PRIVILEGES;
"

# STEP 3: Go to the project directory
cd /home/glory/EdwardKINGS/StudentManagementSystem

# STEP 4: Activate virtual environment
source venv/bin/activate

# STEP 5: Run database migrations
python manage.py migrate

# STEP 6: Seed initial data (grades, streams, subjects, sample students, admin user)
python seed_data.py

# STEP 7: Start the development server
python manage.py runserver

# ==============================================
# After starting:
#   Website: http://127.0.0.1:8000
#   Admin:   http://127.0.0.1:8000/admin/
#   Login:   admin / EKA@admin2024
# ==============================================
