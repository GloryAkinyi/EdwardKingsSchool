from cpanel_api import CPanelAPI
import json

api = CPanelAPI("edwardk1", "E271;a#HwY4emY")
# Try Appman::list_applications
res = api.execute("Appman", "list_applications")
print("Appman applications:")
print(json.dumps(res, indent=2))
