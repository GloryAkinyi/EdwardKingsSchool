from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Avg, Count, Q
from .models import Subject, ExamType, Result, TeacherProfile, Timetable
from academics.models import GradeLevel, Stream, AcademicYear, Term
from students.models import Student
from .forms import TeacherUserForm, TeacherProfileForm, AssignClassTeacherForm


@login_required
def results_entry(request):
    streams = Stream.objects.select_related('grade').all()
    selected_stream = request.GET.get('stream')
    selected_exam = request.GET.get('exam')
    selected_subject = request.GET.get('subject')
    exam_types = ExamType.objects.select_related('term').all()
    subjects = Subject.objects.all()

    students = []
    stream_obj = None
    exam_obj = None
    subject_obj = None

    if selected_stream and selected_exam and selected_subject:
        stream_obj = get_object_or_404(Stream, pk=selected_stream)
        exam_obj = get_object_or_404(ExamType, pk=selected_exam)
        subject_obj = get_object_or_404(Subject, pk=selected_subject)
        students = Student.objects.filter(current_stream=stream_obj, status='active')

    if request.method == 'POST' and stream_obj:
        for student in students:
            marks = request.POST.get(f'marks_{student.pk}')
            remarks = request.POST.get(f'remarks_{student.pk}', '')
            if marks:
                result, _ = Result.objects.update_or_create(
                    student=student, subject=subject_obj, exam_type=exam_obj,
                    defaults={
                        'marks': marks, 'stream': stream_obj,
                        'remarks': remarks, 'entered_by': request.user,
                    }
                )
                result.grade = result.compute_grade()
                result.save()
        messages.success(request, f'Results saved for {stream_obj} - {subject_obj} - {exam_obj}')
        return redirect(f'{request.path}?stream={selected_stream}&exam={selected_exam}&subject={selected_subject}')

    existing_results = {}
    if students and exam_obj and subject_obj:
        for r in Result.objects.filter(student__in=students, exam_type=exam_obj, subject=subject_obj):
            existing_results[r.student_id] = r

    context = {
        'streams': streams,
        'selected_stream': selected_stream,
        'selected_exam': selected_exam,
        'selected_subject': selected_subject,
        'stream_obj': stream_obj,
        'exam_obj': exam_obj,
        'subject_obj': subject_obj,
        'students': students,
        'exam_types': exam_types,
        'subjects': subjects,
        'existing_results': existing_results,
    }
    return render(request, 'academics/results_entry.html', context)


@login_required
def stream_results(request, stream_id):
    stream = get_object_or_404(Stream, pk=stream_id)
    exam_id = request.GET.get('exam')
    exam_types = ExamType.objects.select_related('term').all()
    student_summaries = []
    subjects = Subject.objects.filter(grade_levels=stream.grade)
    exam = None

    if exam_id:
        exam = get_object_or_404(ExamType, pk=exam_id)
        students = Student.objects.filter(current_stream=stream, status='active')
        for student in students:
            results = Result.objects.filter(student=student, exam_type=exam).select_related('subject')
            total = sum(float(r.marks or 0) for r in results)
            avg = total / len(results) if results else 0
            student_summaries.append({
                'student': student,
                'results': {r.subject_id: r for r in results},
                'total': round(total, 2),
                'average': round(avg, 2),
            })
        student_summaries.sort(key=lambda x: x['total'], reverse=True)
        for idx, s in enumerate(student_summaries, 1):
            s['rank'] = idx

    context = {
        'stream': stream,
        'exam': exam,
        'exam_types': exam_types,
        'exam_id': exam_id,
        'student_summaries': student_summaries,
        'subjects': subjects,
    }
    return render(request, 'academics/stream_results.html', context)


@login_required
def timetable_view(request, stream_id):
    stream = get_object_or_404(Stream, pk=stream_id)
    current_term = Term.objects.filter(is_current=True).first()
    timetable = []
    if current_term:
        timetable = Timetable.objects.filter(
            stream=stream, term=current_term
        ).select_related('subject', 'teacher__user').order_by('day', 'start_time')

    days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
    timetable_grid = {day: [] for day in days}
    for slot in timetable:
        timetable_grid[slot.day].append(slot)

    context = {
        'stream': stream,
        'current_term': current_term,
        'timetable_grid': timetable_grid,
        'days': days,
    }
    return render(request, 'academics/timetable.html', context)


@login_required
def subjects_list(request):
    subjects = Subject.objects.prefetch_related('grade_levels', 'teachers').all()
    return render(request, 'academics/subjects.html', {'subjects': subjects})


@login_required
def add_subject(request):
    from .forms import SubjectForm
    if request.method == 'POST':
        form = SubjectForm(request.POST)
        if form.is_valid():
            subject = form.save()
            messages.success(request, f'Subject "{subject.name}" added successfully.')
            return redirect('academics:subjects')
    else:
        form = SubjectForm()
    return render(request, 'academics/subject_form.html', {'form': form, 'action': 'Add'})


@login_required
def edit_subject(request, pk):
    from .forms import SubjectForm
    subject = get_object_or_404(Subject, pk=pk)
    if request.method == 'POST':
        form = SubjectForm(request.POST, instance=subject)
        if form.is_valid():
            form.save()
            messages.success(request, f'Subject "{subject.name}" updated.')
            return redirect('academics:subjects')
    else:
        form = SubjectForm(instance=subject)
    return render(request, 'academics/subject_form.html', {
        'form': form, 'action': 'Edit', 'subject': subject
    })


@login_required
def delete_subject(request, pk):
    subject = get_object_or_404(Subject, pk=pk)
    if request.method == 'POST':
        name = subject.name
        subject.delete()
        messages.success(request, f'Subject "{name}" deleted.')
        return redirect('academics:subjects')
    return render(request, 'academics/subject_confirm_delete.html', {'subject': subject})


@login_required
def teachers_list(request):
    teachers = TeacherProfile.objects.select_related('user').prefetch_related('subjects', 'streams').all()
    return render(request, 'academics/teachers.html', {'teachers': teachers})


@login_required
def add_teacher(request):
    if request.method == 'POST':
        user_form = TeacherUserForm(request.POST)
        profile_form = TeacherProfileForm(request.POST)
        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save(commit=False)
            password = user_form.cleaned_data.get('password')
            if password:
                user.set_password(password)
            else:
                user.set_unusable_password()
            user.save()
            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()
            profile_form.save_m2m()
            messages.success(request, f'Teacher {user.get_full_name()} added successfully.')
            return redirect('academics:teachers')
    else:
        user_form = TeacherUserForm()
        profile_form = TeacherProfileForm()
    return render(request, 'academics/teacher_form.html', {
        'user_form': user_form,
        'profile_form': profile_form,
        'action': 'Add',
    })


@login_required
def edit_teacher(request, pk):
    profile = get_object_or_404(TeacherProfile, pk=pk)
    user = profile.user
    if request.method == 'POST':
        user_form = TeacherUserForm(request.POST, instance=user)
        profile_form = TeacherProfileForm(request.POST, instance=profile)
        if user_form.is_valid() and profile_form.is_valid():
            updated_user = user_form.save(commit=False)
            password = user_form.cleaned_data.get('password')
            if password:
                updated_user.set_password(password)
            updated_user.save()
            profile_form.save()
            messages.success(request, f'Teacher {user.get_full_name()} updated successfully.')
            return redirect('academics:teachers')
    else:
        user_form = TeacherUserForm(instance=user)
        profile_form = TeacherProfileForm(instance=profile)
    return render(request, 'academics/teacher_form.html', {
        'user_form': user_form,
        'profile_form': profile_form,
        'action': 'Edit',
        'teacher': profile,
    })


@login_required
def delete_teacher(request, pk):
    profile = get_object_or_404(TeacherProfile, pk=pk)
    name = profile.user.get_full_name()
    if request.method == 'POST':
        profile.user.delete()  # cascades to TeacherProfile via OneToOne
        messages.success(request, f'Teacher {name} has been removed.')
        return redirect('academics:teachers')
    return render(request, 'academics/teacher_confirm_delete.html', {'teacher': profile})


@login_required
def assign_class_teacher(request, stream_id):
    stream = get_object_or_404(Stream, pk=stream_id)
    if request.method == 'POST':
        form = AssignClassTeacherForm(request.POST, instance=stream)
        if form.is_valid():
            updated_stream = form.save()
            # Refresh to get accurate class_teacher after save
            updated_stream.refresh_from_db()
            teacher = updated_stream.class_teacher
            if teacher:
                msg = f'{teacher.get_full_name()} assigned as class teacher of {stream}.'
            else:
                msg = f'Class teacher removed from {stream}.'
            messages.success(request, msg)
            return redirect('academics:streams_overview')
    else:
        form = AssignClassTeacherForm(instance=stream)

    teachers = TeacherProfile.objects.select_related('user').all()
    return render(request, 'academics/assign_class_teacher.html', {
        'form': form,
        'stream': stream,
        'teachers': teachers,
    })


@login_required
def streams_overview(request):
    import datetime
    from django.db.models import Prefetch, Sum, Subquery, OuterRef, IntegerField, Value
    from django.db.models.functions import Coalesce
    from students.models import Attendance

    today = datetime.date.today()

    # Subquery to count today's attendance records for a stream
    today_att_subquery = Attendance.objects.filter(
        stream=OuterRef('pk'),
        date=today
    ).values('stream').annotate(cnt=Count('id')).values('cnt')

    # Subquery to count today's present records for a stream
    today_present_subquery = Attendance.objects.filter(
        stream=OuterRef('pk'),
        date=today,
        status='present'
    ).values('stream').annotate(cnt=Count('id')).values('cnt')

    streams_qs = Stream.objects.select_related('class_teacher').annotate(
        student_count=Count('students', filter=Q(students__status='active')),
        today_att_count=Coalesce(Subquery(today_att_subquery, output_field=IntegerField()), Value(0)),
        today_present_count=Coalesce(Subquery(today_present_subquery, output_field=IntegerField()), Value(0))
    ).order_by('name')
    
    grades = GradeLevel.objects.prefetch_related(
        Prefetch('streams', queryset=streams_qs)
    ).order_by('order')

    total_streams = Stream.objects.count()
    active_students = Student.objects.filter(status='active').count()
    total_capacity = Stream.objects.aggregate(total=Sum('capacity'))['total'] or 0
    utilization_rate = round((active_students / total_capacity * 100), 1) if total_capacity else 0

    context = {
        'grades': grades,
        'total_streams': total_streams,
        'active_students': active_students,
        'total_capacity': total_capacity,
        'utilization_rate': utilization_rate,
        'today': today,
    }
    return render(request, 'academics/streams.html', context)
