from django.contrib import admin
from .models import (
    AcademicYear, Term, GradeLevel, Stream,
    Subject, ExamType, Result, TeacherProfile, Timetable
)


@admin.register(AcademicYear)
class AcademicYearAdmin(admin.ModelAdmin):
    list_display = ['name', 'start_date', 'end_date', 'is_current']
    list_editable = ['is_current']


@admin.register(Term)
class TermAdmin(admin.ModelAdmin):
    list_display = ['name', 'academic_year', 'start_date', 'end_date', 'is_current']
    list_editable = ['is_current']
    list_filter = ['academic_year', 'is_current']


@admin.register(GradeLevel)
class GradeLevelAdmin(admin.ModelAdmin):
    list_display = ['name', 'level_category', 'order']
    list_editable = ['order']
    ordering = ['order']


@admin.register(Stream)
class StreamAdmin(admin.ModelAdmin):
    list_display = ['__str__', 'grade', 'name', 'class_teacher', 'capacity', 'student_count']
    list_filter = ['grade']
    search_fields = ['name', 'grade__name']

    def student_count(self, obj):
        return obj.student_count
    student_count.short_description = 'Students'


@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ['name', 'code', 'is_core']
    filter_horizontal = ['grade_levels']
    list_filter = ['is_core']


@admin.register(ExamType)
class ExamTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'term', 'weight']
    list_filter = ['term__academic_year', 'term']


@admin.register(Result)
class ResultAdmin(admin.ModelAdmin):
    list_display = ['student', 'subject', 'exam_type', 'stream', 'marks', 'grade']
    list_filter = ['exam_type__term', 'stream', 'subject']
    search_fields = ['student__first_name', 'student__last_name', 'student__admission_number']
    autocomplete_fields = ['student']


@admin.register(TeacherProfile)
class TeacherProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'staff_number', 'phone', 'tsc_number']
    filter_horizontal = ['subjects', 'streams']
    search_fields = ['user__first_name', 'user__last_name', 'staff_number']


@admin.register(Timetable)
class TimetableAdmin(admin.ModelAdmin):
    list_display = ['stream', 'subject', 'teacher', 'day', 'start_time', 'end_time', 'term']
    list_filter = ['stream', 'day', 'term']
