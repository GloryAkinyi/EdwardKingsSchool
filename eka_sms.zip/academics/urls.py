from django.urls import path
from . import views

app_name = 'academics'

urlpatterns = [
    path('streams/', views.streams_overview, name='streams_overview'),
    path('streams/<int:stream_id>/results/', views.stream_results, name='stream_results'),
    path('streams/<int:stream_id>/timetable/', views.timetable_view, name='timetable'),
    path('streams/<int:stream_id>/assign-teacher/', views.assign_class_teacher, name='assign_class_teacher'),
    path('results/', views.results_entry, name='results_entry'),
    # Subject management
    path('subjects/', views.subjects_list, name='subjects'),
    path('subjects/add/', views.add_subject, name='add_subject'),
    path('subjects/<int:pk>/edit/', views.edit_subject, name='edit_subject'),
    path('subjects/<int:pk>/delete/', views.delete_subject, name='delete_subject'),
    # Teacher management
    path('teachers/', views.teachers_list, name='teachers'),
    path('teachers/add/', views.add_teacher, name='add_teacher'),
    path('teachers/<int:pk>/edit/', views.edit_teacher, name='edit_teacher'),
    path('teachers/<int:pk>/delete/', views.delete_teacher, name='delete_teacher'),
]
