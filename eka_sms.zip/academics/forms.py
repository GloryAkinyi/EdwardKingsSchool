from django import forms
from django.contrib.auth.models import User
from .models import Subject, ExamType, Timetable, TeacherProfile, Stream


class TeacherUserForm(forms.ModelForm):
    """Handles the Django User fields for a teacher account."""
    password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Leave blank to keep current password'}),
        help_text='Leave blank when editing to keep the existing password.'
    )
    confirm_password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirm new password'}),
        label='Confirm Password'
    )

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username', 'email']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. John'}),
            'last_name':  forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Mwangi'}),
            'username':   forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Unique login username'}),
            'email':      forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'teacher@edwardkings.sc.ke'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        p1 = cleaned_data.get('password')
        p2 = cleaned_data.get('confirm_password')
        if p1 and p1 != p2:
            self.add_error('confirm_password', 'Passwords do not match.')
        return cleaned_data


class TeacherProfileForm(forms.ModelForm):
    """Handles the TeacherProfile fields."""
    class Meta:
        model = TeacherProfile
        fields = ['staff_number', 'tsc_number', 'phone', 'date_joined', 'subjects', 'streams']
        widgets = {
            'staff_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. EKA-T001'}),
            'tsc_number':   forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'TSC registration number'}),
            'phone':        forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 0712 345 678'}),
            'date_joined':  forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'subjects':     forms.CheckboxSelectMultiple(),
            'streams':      forms.CheckboxSelectMultiple(),
        }


class AssignClassTeacherForm(forms.ModelForm):
    """Assign or remove a class teacher for a stream."""
    class Meta:
        model = Stream
        fields = ['class_teacher']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.contrib.auth.models import User as AuthUser
        teacher_user_ids = TeacherProfile.objects.values_list('user_id', flat=True)
        qs = AuthUser.objects.filter(pk__in=teacher_user_ids).order_by('first_name', 'last_name')
        field = self.fields['class_teacher']
        field.queryset = qs
        field.required = False
        field.empty_label = '— Remove Class Teacher —'
        field.label = 'Select Class Teacher'
        field.widget = forms.Select(attrs={'class': 'form-select form-select-lg'})


class SubjectForm(forms.ModelForm):
    class Meta:
        model = Subject
        fields = '__all__'
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'code': forms.TextInput(attrs={'class': 'form-control'}),
            'grade_levels': forms.CheckboxSelectMultiple(),
        }


class ExamTypeForm(forms.ModelForm):
    class Meta:
        model = ExamType
        fields = '__all__'
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'weight': forms.NumberInput(attrs={'class': 'form-control'}),
            'term': forms.Select(attrs={'class': 'form-select'}),
        }


class ResultForm(forms.Form):
    marks = forms.DecimalField(
        max_digits=6, decimal_places=2,
        required=False,
        widget=forms.NumberInput(attrs={'class': 'form-control form-control-sm', 'min': '0', 'max': '100', 'step': '0.5'})
    )
    remarks = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control form-control-sm', 'placeholder': 'Optional'})
    )


class TimetableForm(forms.ModelForm):
    class Meta:
        model = Timetable
        fields = '__all__'
        widgets = {
            'stream': forms.Select(attrs={'class': 'form-select'}),
            'subject': forms.Select(attrs={'class': 'form-select'}),
            'teacher': forms.Select(attrs={'class': 'form-select'}),
            'day': forms.Select(attrs={'class': 'form-select'}),
            'start_time': forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}),
            'end_time': forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'}),
            'term': forms.Select(attrs={'class': 'form-select'}),
        }
