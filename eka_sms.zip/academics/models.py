from django.db import models
from django.contrib.auth.models import User


class AcademicYear(models.Model):
    name = models.CharField(max_length=20, unique=True)
    start_date = models.DateField()
    end_date = models.DateField()
    is_current = models.BooleanField(default=False)

    class Meta:
        ordering = ['-name']

    def __str__(self):
        return f"Academic Year {self.name}"

    def save(self, *args, **kwargs):
        if self.is_current:
            AcademicYear.objects.exclude(pk=self.pk).update(is_current=False)
        super().save(*args, **kwargs)


class Term(models.Model):
    TERM_CHOICES = [
        ('Term 1', 'Term 1'),
        ('Term 2', 'Term 2'),
        ('Term 3', 'Term 3'),
    ]
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.CASCADE, related_name='terms')
    name = models.CharField(max_length=10, choices=TERM_CHOICES)
    start_date = models.DateField()
    end_date = models.DateField()
    is_current = models.BooleanField(default=False)

    class Meta:
        unique_together = ['academic_year', 'name']
        ordering = ['academic_year', 'name']

    def __str__(self):
        return f"{self.name} - {self.academic_year}"

    def save(self, *args, **kwargs):
        if self.is_current:
            Term.objects.exclude(pk=self.pk).update(is_current=False)
        super().save(*args, **kwargs)


class GradeLevel(models.Model):
    LEVEL_CHOICES = [
        ('pre_primary', 'Pre-Primary (PP1-PP2)'),
        ('primary', 'Primary (Grade 1-6)'),
        ('junior_school', 'Junior School (Grade 7-9)'),
    ]
    name = models.CharField(max_length=20, unique=True)
    level_category = models.CharField(max_length=20, choices=LEVEL_CHOICES)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.name


class Stream(models.Model):
    grade = models.ForeignKey(GradeLevel, on_delete=models.CASCADE, related_name='streams')
    name = models.CharField(max_length=5)
    class_teacher = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='class_teacher_streams'
    )
    capacity = models.PositiveIntegerField(default=40)

    class Meta:
        unique_together = ['grade', 'name']
        ordering = ['grade', 'name']

    def __str__(self):
        return f"{self.grade.name}{self.name}"

    @property
    def full_name(self):
        return f"{self.grade.name} {self.name}"

    @property
    def student_count(self):
        if hasattr(self, '_student_count'):
            return self._student_count
        return self.students.filter(status='active').count()

    @student_count.setter
    def student_count(self, value):
        self._student_count = value


class Subject(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)
    grade_levels = models.ManyToManyField(GradeLevel, related_name='subjects')
    is_core = models.BooleanField(default=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.code} - {self.name}"


class ExamType(models.Model):
    name = models.CharField(max_length=50)
    weight = models.DecimalField(max_digits=5, decimal_places=2, default=100)
    term = models.ForeignKey(Term, on_delete=models.CASCADE, related_name='exam_types')

    class Meta:
        ordering = ['term', 'name']

    def __str__(self):
        return f"{self.name} - {self.term}"


class Result(models.Model):
    GRADE_CHOICES = [
        ('EE', 'Exceeds Expectation'), ('ME', 'Meets Expectation'),
        ('AE', 'Approaches Expectation'), ('BE', 'Below Expectation'),
        ('A', 'A'), ('A-', 'A-'), ('B+', 'B+'), ('B', 'B'), ('B-', 'B-'),
        ('C+', 'C+'), ('C', 'C'), ('C-', 'C-'), ('D+', 'D+'), ('D', 'D'),
        ('D-', 'D-'), ('E', 'E'),
    ]
    student = models.ForeignKey('students.Student', on_delete=models.CASCADE, related_name='results')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    exam_type = models.ForeignKey(ExamType, on_delete=models.CASCADE)
    stream = models.ForeignKey(Stream, on_delete=models.SET_NULL, null=True)
    marks = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    max_marks = models.DecimalField(max_digits=6, decimal_places=2, default=100)
    grade = models.CharField(max_length=3, choices=GRADE_CHOICES, blank=True)
    remarks = models.TextField(blank=True)
    entered_by = models.ForeignKey(
        'auth.User', on_delete=models.SET_NULL, null=True, blank=True
    )

    class Meta:
        unique_together = ['student', 'subject', 'exam_type']
        ordering = ['student', 'subject']

    def __str__(self):
        return f"{self.student.full_name} - {self.subject} - {self.marks}"

    @property
    def percentage(self):
        if self.marks and self.max_marks:
            return round((float(self.marks) / float(self.max_marks)) * 100, 2)
        return 0

    def compute_grade(self):
        pct = self.percentage
        if pct >= 80: return 'A'
        elif pct >= 75: return 'A-'
        elif pct >= 70: return 'B+'
        elif pct >= 65: return 'B'
        elif pct >= 60: return 'B-'
        elif pct >= 55: return 'C+'
        elif pct >= 50: return 'C'
        elif pct >= 45: return 'C-'
        elif pct >= 40: return 'D+'
        elif pct >= 35: return 'D'
        elif pct >= 30: return 'D-'
        else: return 'E'


class TeacherProfile(models.Model):
    user = models.OneToOneField('auth.User', on_delete=models.CASCADE, related_name='teacher_profile')
    staff_number = models.CharField(max_length=20, unique=True)
    phone = models.CharField(max_length=15)
    subjects = models.ManyToManyField(Subject, blank=True, related_name='teachers')
    streams = models.ManyToManyField(Stream, blank=True, related_name='subject_teachers')
    photo = models.ImageField(upload_to='teachers/photos/', blank=True, null=True)
    tsc_number = models.CharField(max_length=20, blank=True)
    date_joined = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.staff_number})"


class Timetable(models.Model):
    DAYS = [
        ('Mon', 'Monday'), ('Tue', 'Tuesday'), ('Wed', 'Wednesday'),
        ('Thu', 'Thursday'), ('Fri', 'Friday'),
    ]
    stream = models.ForeignKey(Stream, on_delete=models.CASCADE, related_name='timetable_slots')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    teacher = models.ForeignKey(TeacherProfile, on_delete=models.SET_NULL, null=True, blank=True)
    day = models.CharField(max_length=3, choices=DAYS)
    start_time = models.TimeField()
    end_time = models.TimeField()
    term = models.ForeignKey(Term, on_delete=models.CASCADE)

    class Meta:
        ordering = ['stream', 'day', 'start_time']

    def __str__(self):
        return f"{self.stream} - {self.subject} - {self.day} {self.start_time}"
