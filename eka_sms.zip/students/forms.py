from django import forms
from .models import Student, Attendance, StreamPromotion
from academics.models import GradeLevel, Stream, AcademicYear


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        exclude = ['admission_number', 'created_at', 'updated_at', 'photo', 'national_id', 'blood_group', 'parent_email', 'parent_occupation', 'home_address']
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'admission_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'middle_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'gender': forms.Select(attrs={'class': 'form-select'}),
            'current_grade': forms.Select(attrs={'class': 'form-select', 'id': 'id_current_grade'}),
            'current_stream': forms.Select(attrs={'class': 'form-select', 'id': 'id_current_stream'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
            'parent_name': forms.TextInput(attrs={'class': 'form-control'}),
            'parent_phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '+254 7XX XXX XXX'}),
            'parent_phone2': forms.TextInput(attrs={'class': 'form-control'}),
            'emergency_contact': forms.TextInput(attrs={'class': 'form-control'}),
            'birth_certificate_no': forms.TextInput(attrs={'class': 'form-control'}),
            'medical_conditions': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['current_stream'].queryset = Stream.objects.select_related('grade').all()
        for field_name, field in self.fields.items():
            if not isinstance(field.widget, (forms.CheckboxInput, forms.FileInput)):
                if 'class' not in field.widget.attrs:
                    field.widget.attrs['class'] = 'form-control'


class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['student', 'stream', 'date', 'status', 'remarks']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
            'remarks': forms.TextInput(attrs={'class': 'form-control'}),
        }


class BulkAttendanceForm(forms.Form):
    stream = forms.ModelChoiceField(
        queryset=Stream.objects.select_related('grade').all(),
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    date = forms.DateField(
        initial=__import__('datetime').date.today,
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'})
    )


class StreamPromotionForm(forms.Form):
    from_stream = forms.ModelChoiceField(
        queryset=Stream.objects.select_related('grade').all(),
        widget=forms.Select(attrs={'class': 'form-select'}),
        label='From Stream'
    )
    to_stream = forms.ModelChoiceField(
        queryset=Stream.objects.select_related('grade').all(),
        widget=forms.Select(attrs={'class': 'form-select'}),
        label='To Stream'
    )
    academic_year = forms.ModelChoiceField(
        queryset=AcademicYear.objects.all(),
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    notes = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 2})
    )
