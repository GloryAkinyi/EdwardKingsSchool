from django.contrib import admin
from .models import Student, Attendance, StreamPromotion


class AttendanceInline(admin.TabularInline):
    model = Attendance
    extra = 0
    max_num = 5
    readonly_fields = ['date', 'status', 'stream', 'marked_by']
    can_delete = False


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = [
        'admission_number', 'full_name', 'gender', 'current_grade',
        'current_stream', 'parent_phone', 'status', 'admission_date'
    ]
    list_filter = ['current_grade', 'current_stream', 'gender', 'status']
    search_fields = [
        'first_name', 'last_name', 'admission_number', 'parent_name', 'parent_phone'
    ]
    readonly_fields = ['admission_number', 'created_at', 'updated_at']
    inlines = [AttendanceInline]
    ordering = ['current_grade__order', 'current_stream__name', 'last_name']

    fieldsets = (
        ('Personal Info', {
            'fields': ('first_name', 'middle_name', 'last_name', 'gender', 'date_of_birth',
                       'blood_group', 'photo', 'birth_certificate_no', 'national_id', 'medical_conditions')
        }),
        ('Academic Placement', {
            'fields': ('admission_number', 'current_grade', 'current_stream', 'admission_date', 'status')
        }),
        ('Parent / Guardian', {
            'fields': ('parent_name', 'parent_phone', 'parent_phone2', 'parent_email',
                       'parent_occupation', 'home_address', 'emergency_contact')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def full_name(self, obj):
        return obj.full_name
    full_name.short_description = 'Name'


@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ['student', 'date', 'stream', 'status', 'marked_by']
    list_filter = ['status', 'stream', 'date']
    search_fields = ['student__first_name', 'student__last_name', 'student__admission_number']
    date_hierarchy = 'date'


@admin.register(StreamPromotion)
class StreamPromotionAdmin(admin.ModelAdmin):
    list_display = ['student', 'from_stream', 'to_stream', 'academic_year', 'promoted_on', 'promoted_by']
    list_filter = ['academic_year', 'from_stream', 'to_stream']
    search_fields = ['student__first_name', 'student__last_name', 'student__admission_number']
    readonly_fields = ['promoted_on']
