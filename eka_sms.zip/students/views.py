from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count
from django.http import JsonResponse
from django.core.paginator import Paginator
from .models import Student, Attendance, StreamPromotion
from academics.models import GradeLevel, Stream, AcademicYear, Term
from .forms import StudentForm, AttendanceForm, BulkAttendanceForm, StreamPromotionForm
import datetime
import json


@login_required
def student_list(request):
    students = Student.objects.select_related('current_grade', 'current_stream').filter(status='active')

    # Filters
    grade = request.GET.get('grade')
    stream = request.GET.get('stream')
    search = request.GET.get('q')
    gender = request.GET.get('gender')

    if grade:
        students = students.filter(current_grade__id=grade)
    if stream:
        students = students.filter(current_stream__id=stream)
    if gender:
        students = students.filter(gender=gender)
    if search:
        students = students.filter(
            Q(first_name__icontains=search) |
            Q(last_name__icontains=search) |
            Q(admission_number__icontains=search) |
            Q(parent_name__icontains=search)
        )

    paginator = Paginator(students, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'grades': GradeLevel.objects.all(),
        'streams': Stream.objects.select_related('grade').all(),
        'selected_grade': grade,
        'selected_stream': stream,
        'search': search,
        'gender': gender,
        'total_count': students.count(),
    }
    return render(request, 'students/student_list.html', context)


@login_required
def student_detail(request, pk):
    student = get_object_or_404(Student, pk=pk)
    attendances_qs = student.attendances.all()
    attendances = attendances_qs.order_by('-date')[:30]
    results = student.results.select_related('subject', 'exam_type').order_by('-exam_type__term__name')
    payments = student.payments.select_related('fee_structure').order_by('-payment_date')
    promotions = student.promotions.select_related(
        'from_grade', 'from_stream', 'to_grade', 'to_stream', 'academic_year'
    )

    # Attendance summary
    total_days = attendances_qs.count()
    present_days = attendances_qs.filter(status='present').count()
    absent_days = attendances_qs.filter(status='absent').count()
    late_days = attendances_qs.filter(status='late').count()
    att_rate = round((present_days / total_days * 100), 1) if total_days else 0

    context = {
        'student': student,
        'attendances': attendances,
        'results': results,
        'payments': payments,
        'promotions': promotions,
        'total_days': total_days,
        'present_days': present_days,
        'absent_days': absent_days,
        'late_days': late_days,
        'att_rate': att_rate,
    }
    return render(request, 'students/student_detail.html', context)


@login_required
def student_add(request):
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            student = form.save()
            messages.success(request, f'Student {student.full_name} added successfully! Admission No: {student.admission_number}')
            return redirect('students:student_detail', pk=student.pk)
    else:
        form = StudentForm()
    return render(request, 'students/student_form.html', {'form': form, 'title': 'Add New Student'})


@login_required
def student_edit(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, f'Student record updated successfully!')
            return redirect('students:student_detail', pk=student.pk)
    else:
        form = StudentForm(instance=student)
    return render(request, 'students/student_form.html', {'form': form, 'title': 'Edit Student', 'student': student})


@login_required
def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        name = student.full_name
        student.status = 'inactive'
        student.save()
        messages.success(request, f'{name} has been deactivated.')
        return redirect('students:student_list')
    return render(request, 'students/student_confirm_delete.html', {'student': student})


@login_required
def mark_attendance(request):
    today = datetime.date.today()
    streams = Stream.objects.select_related('grade').all()
    selected_stream = request.GET.get('stream') or request.POST.get('stream')

    students = []
    stream_obj = None
    if selected_stream:
        stream_obj = get_object_or_404(Stream, pk=selected_stream)
        students = Student.objects.filter(current_stream=stream_obj, status='active')

    if request.method == 'POST' and stream_obj:
        for student in students:
            status = request.POST.get(f'status_{student.pk}', 'absent')
            remarks = request.POST.get(f'remarks_{student.pk}', '')
            Attendance.objects.update_or_create(
                student=student, date=today,
                defaults={'status': status, 'remarks': remarks, 'stream': stream_obj, 'marked_by': request.user}
            )
        messages.success(request, f'Attendance marked for {stream_obj} - {today}')
        return redirect('students:mark_attendance')

    # Pre-fill existing attendance
    existing = {a.student_id: a for a in Attendance.objects.filter(stream=stream_obj, date=today)} if stream_obj else {}

    context = {
        'streams': streams,
        'selected_stream': selected_stream,
        'stream_obj': stream_obj,
        'students': students,
        'today': today,
        'existing': existing,
    }
    return render(request, 'students/attendance.html', context)


@login_required
def promote_students(request):
    if request.method == 'POST':
        form = StreamPromotionForm(request.POST)
        if form.is_valid():
            from_stream = form.cleaned_data['from_stream']
            to_stream = form.cleaned_data['to_stream']
            academic_year = form.cleaned_data['academic_year']
            selected_ids = request.POST.getlist('student_ids')

            promoted = 0
            for sid in selected_ids:
                try:
                    student = Student.objects.get(pk=sid, current_stream=from_stream)
                    StreamPromotion.objects.create(
                        student=student,
                        from_grade=student.current_grade,
                        from_stream=student.current_stream,
                        to_grade=to_stream.grade,
                        to_stream=to_stream,
                        academic_year=academic_year,
                        promoted_by=request.user,
                        notes=form.cleaned_data.get('notes', ''),
                    )
                    student.current_grade = to_stream.grade
                    student.current_stream = to_stream
                    student.save()
                    promoted += 1
                except Student.DoesNotExist:
                    pass
            messages.success(request, f'{promoted} student(s) promoted successfully!')
            return redirect('students:student_list')
    else:
        form = StreamPromotionForm()

    streams = Stream.objects.select_related('grade').all()
    context = {'form': form, 'streams': streams}
    return render(request, 'students/promote.html', context)


@login_required
def get_stream_students(request):
    stream_id = request.GET.get('stream_id')
    students = Student.objects.filter(current_stream_id=stream_id, status='active').values(
        'id', 'first_name', 'last_name', 'admission_number'
    )
    return JsonResponse({'students': list(students)})


@login_required
def attendance_report(request):
    streams = Stream.objects.select_related('grade').all()
    selected_stream = request.GET.get('stream')
    month = request.GET.get('month', datetime.date.today().month)
    year = request.GET.get('year', datetime.date.today().year)

    attendance_data = []
    stream_obj = None
    if selected_stream:
        stream_obj = get_object_or_404(Stream, pk=selected_stream)
        students = Student.objects.filter(current_stream=stream_obj, status='active')
        for student in students:
            records = Attendance.objects.filter(
                student=student, date__month=month, date__year=year
            )
            total = records.count()
            present = records.filter(status='present').count()
            absent = records.filter(status='absent').count()
            late = records.filter(status='late').count()
            rate = round((present / total * 100), 1) if total else 0
            attendance_data.append({
                'student': student,
                'total': total, 'present': present,
                'absent': absent, 'late': late, 'rate': rate
            })

    context = {
        'streams': streams,
        'selected_stream': selected_stream,
        'stream_obj': stream_obj,
        'attendance_data': attendance_data,
        'month': int(month),
        'year': int(year),
        'months': list(range(1, 13)),
        'years': list(range(datetime.date.today().year - 3, datetime.date.today().year + 1)),
    }
    return render(request, 'students/attendance_report.html', context)
