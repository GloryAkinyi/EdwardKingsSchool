from django.db import models
from django.contrib.auth.models import User
from academics.models import GradeLevel, Stream, AcademicYear, Term
from django.utils import timezone
import datetime


def student_photo_path(instance, filename):
    ext = filename.split('.')[-1]
    return f'students/photos/{instance.admission_number}.{ext}'


class Student(models.Model):
    GENDER_CHOICES = [('M', 'Male'), ('F', 'Female')]
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('transferred', 'Transferred'),
        ('graduated', 'Graduated'),
        ('suspended', 'Suspended'),
    ]
    BLOOD_GROUP_CHOICES = [
        ('A+', 'A+'), ('A-', 'A-'), ('B+', 'B+'), ('B-', 'B-'),
        ('AB+', 'AB+'), ('AB-', 'AB-'), ('O+', 'O+'), ('O-', 'O-'),
    ]

    # Identification
    admission_number = models.CharField(max_length=20, unique=True)
    first_name = models.CharField(max_length=50)
    middle_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    date_of_birth = models.DateField()
    birth_certificate_no = models.CharField(max_length=30, blank=True)
    national_id = models.CharField(max_length=20, blank=True, verbose_name='National ID / NEMIS No')
    photo = models.ImageField(upload_to=student_photo_path, blank=True, null=True)
    blood_group = models.CharField(max_length=3, choices=BLOOD_GROUP_CHOICES, blank=True)
    medical_conditions = models.TextField(blank=True)

    # Academic placement
    current_grade = models.ForeignKey(GradeLevel, on_delete=models.SET_NULL, null=True, blank=True)
    current_stream = models.ForeignKey(
        Stream, on_delete=models.SET_NULL, null=True, blank=True, related_name='students'
    )
    admission_date = models.DateField(default=timezone.now)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='active')

    # Contact/Guardian
    parent_name = models.CharField(max_length=100)
    parent_phone = models.CharField(max_length=15)
    parent_phone2 = models.CharField(max_length=15, blank=True)
    parent_email = models.EmailField(blank=True)
    parent_occupation = models.CharField(max_length=100, blank=True)
    home_address = models.TextField(blank=True)
    emergency_contact = models.CharField(max_length=15, blank=True)

    # Meta
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['current_grade__order', 'current_stream__name', 'last_name', 'first_name']

    def __str__(self):
        return f"{self.admission_number} - {self.full_name}"

    @property
    def full_name(self):
        parts = [self.first_name, self.middle_name, self.last_name]
        return ' '.join(p for p in parts if p)

    @property
    def age(self):
        today = datetime.date.today()
        return today.year - self.date_of_birth.year - (
            (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day)
        )

    def save(self, *args, **kwargs):
        if not self.admission_number:
            year = timezone.now().year
            last = Student.objects.filter(
                admission_number__startswith=f'EKA{year}'
            ).order_by('-admission_number').first()
            if last:
                try:
                    num = int(last.admission_number[-4:]) + 1
                except ValueError:
                    num = 1
            else:
                num = 1
            self.admission_number = f'EKA{year}{num:04d}'
        super().save(*args, **kwargs)


class StreamPromotion(models.Model):
    """Records when a student is promoted/transferred between streams/grades"""
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='promotions')
    from_grade = models.ForeignKey(GradeLevel, on_delete=models.SET_NULL, null=True, related_name='+')
    from_stream = models.ForeignKey(Stream, on_delete=models.SET_NULL, null=True, related_name='+')
    to_grade = models.ForeignKey(GradeLevel, on_delete=models.SET_NULL, null=True, related_name='+')
    to_stream = models.ForeignKey(Stream, on_delete=models.SET_NULL, null=True, related_name='+')
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.SET_NULL, null=True)
    promoted_on = models.DateField(auto_now_add=True)
    promoted_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-promoted_on']

    def __str__(self):
        return f"{self.student} promoted from {self.from_stream} to {self.to_stream}"


class Attendance(models.Model):
    STATUS_CHOICES = [
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('late', 'Late'),
        ('excused', 'Excused'),
    ]
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='attendances')
    stream = models.ForeignKey(Stream, on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='present')
    remarks = models.CharField(max_length=200, blank=True)
    marked_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    class Meta:
        unique_together = ['student', 'date']
        ordering = ['-date']

    def __str__(self):
        return f"{self.student.full_name} - {self.date} - {self.status}"
