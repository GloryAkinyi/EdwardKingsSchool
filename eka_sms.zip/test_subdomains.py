from cpanel_api import CPanelAPI
import json

api = CPanelAPI("edwardk1", "E271;a#HwY4emY")
res = api.execute("DomainInfo", "list_domains")
print(json.dumps(res, indent=2))
