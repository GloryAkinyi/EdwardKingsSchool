from django.urls import path
from . import views

app_name = 'reports'

urlpatterns = [
    path('', views.reports_home, name='home'),
    path('summary/', views.school_summary, name='summary'),
    path('top-performers/', views.top_performers, name='top_performers'),
]
