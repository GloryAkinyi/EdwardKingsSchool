from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Avg, Q, Sum
from students.models import Student
from academics.models import GradeLevel, Stream, Result, ExamType
from fees.models import FeePayment


@login_required
def reports_home(request):
    return render(request, 'reports/home.html')


@login_required
def school_summary(request):
    grades = GradeLevel.objects.annotate(
        total_students=Count('streams__students', filter=Q(streams__students__status='active')),
        total_streams=Count('streams'),
        male=Count('streams__students', filter=Q(streams__students__status='active', streams__students__gender='M')),
        female=Count('streams__students', filter=Q(streams__students__status='active', streams__students__gender='F')),
    ).order_by('order')

    total_active = Student.objects.filter(status='active').count()
    total_male = Student.objects.filter(status='active', gender='M').count()
    total_female = Student.objects.filter(status='active', gender='F').count()

    context = {
        'grades': grades,
        'total_active': total_active,
        'total_male': total_male,
        'total_female': total_female,
    }
    return render(request, 'reports/school_summary.html', context)


@login_required
def top_performers(request):
    exam_types = ExamType.objects.select_related('term').all()
    selected_exam = request.GET.get('exam')
    selected_grade = request.GET.get('grade')
    performers = []
    grades = GradeLevel.objects.all()
    exam = None

    if selected_exam:
        exam = ExamType.objects.get(pk=selected_exam)
        qs = Student.objects.filter(status='active')
        if selected_grade:
            qs = qs.filter(current_grade__id=selected_grade)

        for student in qs:
            results = Result.objects.filter(student=student, exam_type=exam)
            total = sum(float(r.marks or 0) for r in results)
            subjects_count = results.count()
            avg = total / subjects_count if subjects_count else 0
            if subjects_count > 0:
                performers.append({
                    'student': student,
                    'total': round(total, 2),
                    'average': round(avg, 2),
                    'subjects': subjects_count,
                })

        performers.sort(key=lambda x: x['total'], reverse=True)
        for idx, p in enumerate(performers, 1):
            p['rank'] = idx
        performers = performers[:50]  # Top 50

    context = {
        'exam_types': exam_types,
        'selected_exam': selected_exam,
        'selected_grade': selected_grade,
        'grades': grades,
        'performers': performers,
        'exam': exam,
    }
    return render(request, 'reports/top_performers.html', context)
