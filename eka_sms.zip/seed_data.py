"""
Seed script to populate Edward Kings Academy SMS with initial data.
Run with: python manage.py runscript seed_data
OR: python manage.py shell < seed_data.py
"""

import os
import sys
import django

# If run directly
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edwardkings.settings')
django.setup()

from django.contrib.auth.models import User
from academics.models import AcademicYear, Term, GradeLevel, Stream, Subject, ExamType
from students.models import Student
import datetime

print("🏫 Seeding Edward Kings Academy SMS...")

# ── Academic Year ──────────────────────────────────────────
year, _ = AcademicYear.objects.get_or_create(
    name='2024',
    defaults={
        'start_date': datetime.date(2024, 1, 8),
        'end_date': datetime.date(2024, 11, 29),
        'is_current': True,
    }
)
print(f"  ✓ Academic Year: {year}")

# ── Terms ─────────────────────────────────────────────────
t1, _ = Term.objects.get_or_create(academic_year=year, name='Term 1', defaults={
    'start_date': datetime.date(2024, 1, 8),
    'end_date': datetime.date(2024, 4, 5),
    'is_current': True,
})
t2, _ = Term.objects.get_or_create(academic_year=year, name='Term 2', defaults={
    'start_date': datetime.date(2024, 5, 6),
    'end_date': datetime.date(2024, 8, 2),
    'is_current': False,
})
t3, _ = Term.objects.get_or_create(academic_year=year, name='Term 3', defaults={
    'start_date': datetime.date(2024, 9, 2),
    'end_date': datetime.date(2024, 11, 29),
    'is_current': False,
})
print(f"  ✓ Terms: Term 1, 2, 3")

# ── Grade Levels ───────────────────────────────────────────
grade_data = [
    # name, category, order
    ('PP1', 'pre_primary', 1),
    ('PP2', 'pre_primary', 2),
    ('Grade 1', 'primary', 3),
    ('Grade 2', 'primary', 4),
    ('Grade 3', 'primary', 5),
    ('Grade 4', 'primary', 6),
    ('Grade 5', 'primary', 7),
    ('Grade 6', 'primary', 8),
    ('Grade 7', 'junior_school', 9),
    ('Grade 8', 'junior_school', 10),
    ('Grade 9', 'junior_school', 11),
]

grades = {}
for name, cat, order in grade_data:
    g, _ = GradeLevel.objects.get_or_create(name=name, defaults={'level_category': cat, 'order': order})
    grades[name] = g

print(f"  ✓ Grade Levels: PP1-PP2, Grade 1-9")

# ── Streams ────────────────────────────────────────────────
# PP1-PP2: 1 stream each
# Grade 1-6: A, B streams
# Grade 7-9: A, B, C streams
stream_config = {
    'PP1': ['A'],
    'PP2': ['A'],
    'Grade 1': ['A', 'B'],
    'Grade 2': ['A', 'B'],
    'Grade 3': ['A', 'B'],
    'Grade 4': ['A', 'B'],
    'Grade 5': ['A', 'B'],
    'Grade 6': ['A', 'B'],
    'Grade 7': ['A', 'B', 'C'],
    'Grade 8': ['A', 'B', 'C'],
    'Grade 9': ['A', 'B', 'C'],
}

streams = {}
for grade_name, stream_names in stream_config.items():
    for sname in stream_names:
        s, _ = Stream.objects.get_or_create(
            grade=grades[grade_name], name=sname,
            defaults={'capacity': 40}
        )
        streams[f"{grade_name}{sname}"] = s

print(f"  ✓ Streams: {Stream.objects.count()} total streams created")

# ── Subjects ───────────────────────────────────────────────
subjects_data = [
    # (code, name, grades...)
    ('ENG', 'English', ['PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('KIS', 'Kiswahili', ['PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('MAT', 'Mathematics', ['PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('SCI', 'Integrated Science', ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6']),
    ('SST', 'Social Studies', ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6']),
    ('CRE', 'C.R.E', ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('PHY', 'Physics', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('CHE', 'Chemistry', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('BIO', 'Biology', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('HIS', 'History & Citizenship', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('GEO', 'Geography', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('BST', 'Business Studies', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('ICT', 'Computer Studies', ['Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('ART', 'Creative Arts', ['PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6']),
]

for code, name, grade_names in subjects_data:
    sub, _ = Subject.objects.get_or_create(code=code, defaults={'name': name})
    for gname in grade_names:
        if gname in grades:
            sub.grade_levels.add(grades[gname])

print(f"  ✓ Subjects: {Subject.objects.count()} subjects")

# ── Exam Types ─────────────────────────────────────────────
exam_types_data = [
    ('CAT 1', t1), ('Mid-Term', t1), ('End-Term', t1),
    ('CAT 1', t2), ('Mid-Term', t2), ('End-Term', t2),
    ('CAT 1', t3), ('Mid-Term', t3), ('End-Term', t3),
]
for name, term in exam_types_data:
    ExamType.objects.get_or_create(name=name, term=term, defaults={'weight': 100})

print(f"  ✓ Exam Types: {ExamType.objects.count()} types")

# ── Admin User ─────────────────────────────────────────────
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser(
        username='admin',
        password='EKA@admin2024',
        email='admin@edwardkings.sc.ke',
        first_name='School',
        last_name='Administrator'
    )
    print("  ✓ Admin user created: admin / EKA@admin2024")
else:
    print("  ✓ Admin user already exists")

# ── Sample Students ────────────────────────────────────────
sample_students = [
    ('Ahmed', 'Omar', 'M', 'Grade 7', 'A', 'Fatima Omar', '+254 712 345678'),
    ('Amina', 'Hassan', 'F', 'Grade 7', 'A', 'Hassan Ali', '+254 713 456789'),
    ('Brian', 'Mwangi', 'M', 'Grade 7', 'B', 'James Mwangi', '+254 714 567890'),
    ('Cynthia', 'Achieng', 'F', 'Grade 7', 'B', 'John Achieng', '+254 715 678901'),
    ('David', 'Kamau', 'M', 'Grade 8', 'A', 'Peter Kamau', '+254 716 789012'),
    ('Esther', 'Wanjiru', 'F', 'Grade 8', 'A', 'Samuel Wanjiru', '+254 717 890123'),
    ('Farhan', 'Ahmed', 'M', 'Grade 9', 'A', 'Ahmed Farah', '+254 718 901234'),
    ('Grace', 'Otieno', 'F', 'Grade 9', 'B', 'Tom Otieno', '+254 719 012345'),
    ('Hassan', 'Salim', 'M', 'Grade 4', 'A', 'Salim Juma', '+254 720 123456'),
    ('Irene', 'Anyango', 'F', 'Grade 4', 'B', 'Peter Anyango', '+254 721 234567'),
    ('Joseph', 'Mutua', 'M', 'Grade 5', 'A', 'Moses Mutua', '+254 722 345678'),
    ('Khadija', 'Ali', 'F', 'Grade 5', 'A', 'Ali Mohamed', '+254 723 456789'),
    ('Levi', 'Ouma', 'M', 'Grade 6', 'A', 'Joshua Ouma', '+254 724 567890'),
    ('Mary', 'Njoroge', 'F', 'Grade 6', 'B', 'David Njoroge', '+254 725 678901'),
    ('Noah', 'Kipchoge', 'M', 'Grade 3', 'A', 'Paul Kipchoge', '+254 726 789012'),
    ('Olivia', 'Mutheu', 'F', 'Grade 2', 'A', 'John Mutheu', '+254 727 890123'),
    ('Patrick', 'Kariuki', 'M', 'Grade 1', 'A', 'Joseph Kariuki', '+254 728 901234'),
    ('Quinn', 'Auma', 'F', 'PP2', 'A', 'George Auma', '+254 729 012345'),
    ('Rashid', 'Juma', 'M', 'PP1', 'A', 'Juma Salim', '+254 730 123456'),
    ('Sophia', 'Wachira', 'F', 'Grade 8', 'C', 'Michael Wachira', '+254 731 234567'),
]

created = 0
for fn, ln, gender, grade, stream, parent, phone in sample_students:
    key = f"{grade}{stream}"
    if key in streams:
        s, c = Student.objects.get_or_create(
            first_name=fn, last_name=ln,
            defaults={
                'gender': gender,
                'date_of_birth': datetime.date(2012, 3, 15),
                'current_grade': grades.get(grade),
                'current_stream': streams.get(key),
                'parent_name': parent,
                'parent_phone': phone,
                'status': 'active',
            }
        )
        if c:
            created += 1

print(f"  ✓ Sample Students: {created} new students added ({Student.objects.count()} total)")
print("\n✅ Seed data complete!")
print("   Login URL: http://127.0.0.1:8000/login/")
print("   Admin URL: http://127.0.0.1:8000/admin/")
print("   Credentials: admin / EKA@admin2024")
