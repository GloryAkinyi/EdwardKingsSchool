import urllib.request
import urllib.parse
import re
import ssl
import http.cookiejar

context = ssl._create_unverified_context()
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(
    urllib.request.HTTPCookieProcessor(cj),
    urllib.request.HTTPSHandler(context=context)
)

# Step 1: Login
url = "https://cpanel.edwardkings.sc.ke:2083/login/?login_only=1"
data = urllib.parse.urlencode({
    "user": "edwardk1",
    "pass": "E271;a#HwY4emY"
}).encode('utf-8')

req = urllib.request.Request(url, data=data)
token = None
with opener.open(req) as res:
    import json
    body = json.loads(res.read().decode('utf-8'))
    token = body.get("security_token")

if not token:
    print("Login failed")
    exit(1)

# Step 2: Get Dashboard HTML
dash_url = f"https://cpanel.edwardkings.sc.ke:2083{token}/frontend/jupiter/index.html"
req = urllib.request.Request(dash_url)
with opener.open(req) as res:
    html = res.read().decode('utf-8', errors='ignore')
    
# Step 3: Find links/features containing python, selector, web, app
features = re.findall(r'href="([^"]+)"[^>]*>([^<]+)', html)
print("All matches:")
for href, name in features:
    name_clean = name.strip()
    if any(x in href.lower() or x in name_clean.lower() for x in ["python", "app", "db", "mysql", "php", "sql", "select", "passenger"]):
        print(f"Name: {name_clean} | Href: {href}")

# Let's search raw html for Python
if "python" in html.lower():
    print("Found 'python' in html!")
    # Print lines containing python
    for line in html.split('\n'):
        if "python" in line.lower():
            print("LINE:", line[:200])
else:
    print("Did NOT find 'python' in html.")
