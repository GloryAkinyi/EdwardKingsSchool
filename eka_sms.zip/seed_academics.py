"""
Seed script to populate Grade Levels, Streams, Subjects, and Terms for Edward Kings Academy.
Run with: python seed_academics.py
"""

import os
import sys
import django

# If run directly
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edwardkings.settings')
django.setup()

from django.contrib.auth.models import User
from academics.models import AcademicYear, Term, GradeLevel, Stream, Subject, ExamType
import datetime

print("🏫 Seeding Edward Kings Academy Academic Metadata...")

# ── Academic Year ──────────────────────────────────────────
year, _ = AcademicYear.objects.get_or_create(
    name='2024',
    defaults={
        'start_date': datetime.date(2024, 1, 8),
        'end_date': datetime.date(2024, 11, 29),
        'is_current': True,
    }
)
print(f"  ✓ Academic Year: {year}")

# ── Terms ─────────────────────────────────────────────────
t1, _ = Term.objects.get_or_create(academic_year=year, name='Term 1', defaults={
    'start_date': datetime.date(2024, 1, 8),
    'end_date': datetime.date(2024, 4, 5),
    'is_current': True,
})
t2, _ = Term.objects.get_or_create(academic_year=year, name='Term 2', defaults={
    'start_date': datetime.date(2024, 5, 6),
    'end_date': datetime.date(2024, 8, 2),
    'is_current': False,
})
t3, _ = Term.objects.get_or_create(academic_year=year, name='Term 3', defaults={
    'start_date': datetime.date(2024, 9, 2),
    'end_date': datetime.date(2024, 11, 29),
    'is_current': False,
})
print(f"  ✓ Terms: Term 1, 2, 3")

# ── Grade Levels ───────────────────────────────────────────
grade_data = [
    ('PP1', 'pre_primary', 1),
    ('PP2', 'pre_primary', 2),
    ('Grade 1', 'primary', 3),
    ('Grade 2', 'primary', 4),
    ('Grade 3', 'primary', 5),
    ('Grade 4', 'primary', 6),
    ('Grade 5', 'primary', 7),
    ('Grade 6', 'primary', 8),
    ('Grade 7', 'junior_school', 9),
    ('Grade 8', 'junior_school', 10),
    ('Grade 9', 'junior_school', 11),
]

grades = {}
for name, cat, order in grade_data:
    g, _ = GradeLevel.objects.get_or_create(name=name, defaults={'level_category': cat, 'order': order})
    grades[name] = g

print(f"  ✓ Grade Levels: PP1-PP2, Grade 1-9")

# ── Streams ────────────────────────────────────────────────
stream_config = {
    'PP1': ['A'],
    'PP2': ['A'],
    'Grade 1': ['A', 'B'],
    'Grade 2': ['A', 'B'],
    'Grade 3': ['A', 'B'],
    'Grade 4': ['A', 'B'],
    'Grade 5': ['A', 'B'],
    'Grade 6': ['A', 'B'],
    'Grade 7': ['A', 'B', 'C'],
    'Grade 8': ['A', 'B', 'C'],
    'Grade 9': ['A', 'B', 'C'],
}

streams = {}
for grade_name, stream_names in stream_config.items():
    for sname in stream_names:
        s, _ = Stream.objects.get_or_create(
            grade=grades[grade_name], name=sname,
            defaults={'capacity': 40}
        )
        streams[f"{grade_name}{sname}"] = s

print(f"  ✓ Streams: {Stream.objects.count()} total streams created")

# ── Subjects ───────────────────────────────────────────────
subjects_data = [
    ('ENG', 'English', ['PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('KIS', 'Kiswahili', ['PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('MAT', 'Mathematics', ['PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('SCI', 'Integrated Science', ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6']),
    ('SST', 'Social Studies', ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6']),
    ('CRE', 'C.R.E', ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('PHY', 'Physics', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('CHE', 'Chemistry', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('BIO', 'Biology', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('HIS', 'History & Citizenship', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('GEO', 'Geography', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('BST', 'Business Studies', ['Grade 7', 'Grade 8', 'Grade 9']),
    ('ICT', 'Computer Studies', ['Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9']),
    ('ART', 'Creative Arts', ['PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6']),
]

for code, name, grade_names in subjects_data:
    sub, _ = Subject.objects.get_or_create(code=code, defaults={'name': name})
    for gname in grade_names:
        if gname in grades:
            sub.grade_levels.add(grades[gname])

print(f"  ✓ Subjects: {Subject.objects.count()} subjects")

# ── Exam Types ─────────────────────────────────────────────
exam_types_data = [
    ('CAT 1', t1), ('Mid-Term', t1), ('End-Term', t1),
    ('CAT 1', t2), ('Mid-Term', t2), ('End-Term', t2),
    ('CAT 1', t3), ('Mid-Term', t3), ('End-Term', t3),
]
for name, term in exam_types_data:
    ExamType.objects.get_or_create(name=name, term=term, defaults={'weight': 100})

print(f"  ✓ Exam Types: {ExamType.objects.count()} types")

# ── Superuser (Admin) ──────────────────────────────────────
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser(
        username='admin',
        password='EKA@admin2024',
        email='admin@edwardkings.sc.ke',
        first_name='School',
        last_name='Administrator'
    )
    print("  ✓ Admin user created: admin / EKA@admin2024")

print("\n✅ Academic seeding complete!")
