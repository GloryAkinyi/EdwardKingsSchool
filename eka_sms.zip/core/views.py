from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum, Q
from django.utils import timezone
from students.models import Student, Attendance
from academics.models import Stream, GradeLevel, AcademicYear, Term
from fees.models import FeePayment, FeeStructure
import datetime


@login_required
def dashboard(request):
    today = datetime.date.today()

    # Core Stats
    total_students = Student.objects.filter(status='active').count()
    male_students = Student.objects.filter(status='active', gender='M').count()
    female_students = Student.objects.filter(status='active', gender='F').count()
    total_streams = Stream.objects.count()
    total_grades = GradeLevel.objects.count()

    # Today's attendance
    today_present = Attendance.objects.filter(date=today, status='present').count()
    today_absent = Attendance.objects.filter(date=today, status='absent').count()
    attendance_rate = round((today_present / total_students * 100), 1) if total_students else 0

    # Fee collection this month
    this_month_fees = FeePayment.objects.filter(
        payment_date__month=today.month,
        payment_date__year=today.year
    ).aggregate(total=Sum('amount_paid'))['total'] or 0

    # Streams with student counts
    streams_data = Stream.objects.annotate(
        student_count=Count('students', filter=Q(students__status='active'))
    ).select_related('grade', 'class_teacher')

    # Grade-level breakdown
    grade_stats = GradeLevel.objects.annotate(
        active_students=Count('streams__students', filter=Q(streams__students__status='active'))
    ).order_by('order')

    # Recent admissions
    recent_students = Student.objects.filter(status='active').order_by('-admission_date')[:5]

    # Defaulters (students with partial/no payment)
    try:
        current_term = Term.objects.filter(is_current=True).first()
    except:
        current_term = None

    context = {
        'total_students': total_students,
        'male_students': male_students,
        'female_students': female_students,
        'total_streams': total_streams,
        'total_grades': total_grades,
        'today_present': today_present,
        'today_absent': today_absent,
        'attendance_rate': attendance_rate,
        'this_month_fees': this_month_fees,
        'streams_data': streams_data,
        'grade_stats': grade_stats,
        'recent_students': recent_students,
        'current_term': current_term,
        'today': today,
    }
    return render(request, 'core/dashboard.html', context)
