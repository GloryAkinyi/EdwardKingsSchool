from django import template

register = template.Library()


@register.filter
def get_item(dictionary, key):
    """Allows dict[key] access in templates: {{ mydict|get_item:key }}"""
    if dictionary is None:
        return None
    if isinstance(dictionary, dict):
        return dictionary.get(key)
    return None


@register.filter
def default_if_none(value, default):
    return value if value is not None else default


@register.filter
def percentage_of(value, total):
    try:
        return (float(value) / float(total)) * 100
    except (ValueError, ZeroDivisionError, TypeError):
        return 0

