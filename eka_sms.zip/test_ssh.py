import socket

for port in [22, 2222]:
    try:
        s = socket.create_connection(("cpanel.edwardkings.sc.ke", port), timeout=3)
        print(f"Port {port} is OPEN! Banner:", s.recv(1024))
        s.close()
    except Exception as e:
        print(f"Port {port} is CLOSED: {e}")
