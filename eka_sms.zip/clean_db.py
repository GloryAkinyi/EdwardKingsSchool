import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edwardkings.settings')
django.setup()

from django.contrib.auth.models import User
from students.models import Student, Attendance, StreamPromotion
from academics.models import AcademicYear, Term, GradeLevel, Stream, Subject, ExamType, Result, TeacherProfile, Timetable
from fees.models import FeeStructure, FeeItem, FeePayment

print("🗑️ Deleting all records from database except superusers...")

# Delete in order of dependencies (child to parent) to avoid FK constraint errors
print("Deleting Results...")
Result.objects.all().delete()

print("Deleting Attendance...")
Attendance.objects.all().delete()

print("Deleting StreamPromotions...")
StreamPromotion.objects.all().delete()

print("Deleting Timetable entries...")
Timetable.objects.all().delete()

print("Deleting FeePayments...")
FeePayment.objects.all().delete()

print("Deleting FeeItems...")
FeeItem.objects.all().delete()

print("Deleting FeeStructures...")
FeeStructure.objects.all().delete()

print("Deleting Students...")
Student.objects.all().delete()

print("Deleting TeacherProfiles...")
TeacherProfile.objects.all().delete()

print("Deleting Streams...")
Stream.objects.all().delete()

print("Deleting Subjects...")
Subject.objects.all().delete()

print("Deleting ExamTypes...")
ExamType.objects.all().delete()

print("Deleting Terms...")
Term.objects.all().delete()

print("Deleting AcademicYears...")
AcademicYear.objects.all().delete()

print("Deleting GradeLevels...")
GradeLevel.objects.all().delete()

# Delete non-superuser accounts
print("Deleting non-superuser Users...")
deleted_users, _ = User.objects.filter(is_superuser=False).delete()
print(f"Deleted {deleted_users} non-superuser accounts.")

print("✨ Cleanup complete!")
