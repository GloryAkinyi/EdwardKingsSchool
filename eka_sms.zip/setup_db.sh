#!/bin/bash
# Edward Kings Academy SMS - MySQL Database Setup Script
# Run this script with: bash setup_db.sh
# You'll be prompted for your MySQL root password

echo "============================================"
echo "  Edward Kings Academy SMS - DB Setup"
echo "============================================"
echo ""
echo "This will create the MySQL database and user."
echo "You'll be prompted for your MySQL root password."
echo ""

mysql -u root -p <<EOF
CREATE DATABASE IF NOT EXISTS edwardkings_sms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'edwardkings'@'localhost' IDENTIFIED BY 'EKings2024#';
GRANT ALL PRIVILEGES ON edwardkings_sms.* TO 'edwardkings'@'localhost';
FLUSH PRIVILEGES;
SELECT 'Database edwardkings_sms created successfully!' AS Status;
SHOW DATABASES LIKE 'edwardkings_sms';
EOF

echo ""
echo "✅ Database setup complete!"
echo "   DB Name: edwardkings_sms"
echo "   DB User: edwardkings"
echo "   Password: EKings2024#"
